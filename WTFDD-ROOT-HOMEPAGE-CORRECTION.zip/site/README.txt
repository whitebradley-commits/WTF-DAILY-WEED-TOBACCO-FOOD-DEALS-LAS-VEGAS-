Replace only index.html at the GitHub repository root. This is the marijuana-leaf WTFdd.com homepage. Keep best-of-period.html and fn-team-original.html separate in the same folder.
