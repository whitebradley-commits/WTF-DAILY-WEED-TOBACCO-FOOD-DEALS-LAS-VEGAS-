Replace only fn-team-original.html. This version has no embedded MP3 files; the three Music options are generated in the browser.
