Upload only these two files to the GitHub root:
- best-of-period.html
- fn-team-original.html
Keep index.html and CNAME unchanged.

Best of Period includes the compact red city reel, stable single orb dock, and San Diego Coast territory Cheesesteak blocks. FN Team includes the smaller MUSIC orb and closeable ONE / TWO / THREE / OFF popup.
