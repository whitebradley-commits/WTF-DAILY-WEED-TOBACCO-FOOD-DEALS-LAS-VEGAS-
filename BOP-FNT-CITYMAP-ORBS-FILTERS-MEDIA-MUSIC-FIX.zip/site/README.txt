Replace best-of-period.html and fn-team-original.html only. Keep index.html and CNAME unchanged.
