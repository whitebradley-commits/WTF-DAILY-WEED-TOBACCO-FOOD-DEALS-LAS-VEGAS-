Replace only best-of-period.html. This build removes conflicting landing, search, and dock layers.
