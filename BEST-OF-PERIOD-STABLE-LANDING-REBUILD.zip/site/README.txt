Replace best-of-period.html only. This clean landing rebuild keeps the original five-orb dock and adds one fast, continuous red city reel.
