# WTFdd Apple-Link Upload Package

This folder contains the two files that must be uploaded **together** to the same GitHub Pages publishing folder.

| File | Purpose |
|---|---|
| `index.html` | The main WTFdd page. The apple in the large WTF logo is the private link. |
| `private-page.html` | The private destination page that opens when the apple is selected. |

## Upload steps

1. In the GitHub repository that publishes `wtfdd.com`, open the publishing folder, normally the repository root or `/docs`.
2. Upload or replace **both** `index.html` and `private-page.html` in that exact same folder. Do not rename either file.
3. Commit the changes and wait for GitHub Pages to finish deploying.
4. Open `https://wtfdd.com`, select the apple in the main WTF logo, and it will open `https://wtfdd.com/private-page.html`.

> The 404 occurred because `private-page.html` was not yet present in the published GitHub Pages folder. Uploading only `index.html` cannot create the destination page.
