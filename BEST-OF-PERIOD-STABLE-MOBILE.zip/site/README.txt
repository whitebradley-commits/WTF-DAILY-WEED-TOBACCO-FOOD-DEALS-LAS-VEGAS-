Replace best-of-period.html only. This version stabilizes the landing city reel, tightens the city-to-Period gap to 6px, and uses one live-city search result panel.
