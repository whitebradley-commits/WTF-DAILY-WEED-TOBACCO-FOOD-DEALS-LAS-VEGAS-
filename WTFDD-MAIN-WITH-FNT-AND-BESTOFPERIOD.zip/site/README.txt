KEEP your existing CNAME file in the GitHub repository.

Upload these three files to the SAME root folder:
- index.html: the marijuana-leaf WTFdd.com homepage (this is the only root page).
- fn-team-original.html: opened only from the Facebook icon; contains the Folded Shirt Stacks gallery image.
- index25.html: opened only from the High & Hungry Best of Period orb.

Do not rename fn-team-original.html or index25.html. Do not rename either secondary page to index.html.
