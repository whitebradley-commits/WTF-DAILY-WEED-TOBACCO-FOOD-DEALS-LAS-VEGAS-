Replace fn-team-original.html with this file. The first Folded Shirt Stacks card now carries an embedded image, so it loads on GitHub without a separate asset file.
