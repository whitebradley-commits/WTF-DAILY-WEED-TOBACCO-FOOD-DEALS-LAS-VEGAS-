Replace index.html and best-of-period.html in the same GitHub root folder. High & Hungry now opens best-of-period.html?landing=orbits, forcing the five-orb Best of Period landing screen.
