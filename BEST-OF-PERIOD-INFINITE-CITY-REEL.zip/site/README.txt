Replace best-of-period.html only. The landing city title now cycles continuously; the bottom five-orb ocean-wave animation is unchanged.
