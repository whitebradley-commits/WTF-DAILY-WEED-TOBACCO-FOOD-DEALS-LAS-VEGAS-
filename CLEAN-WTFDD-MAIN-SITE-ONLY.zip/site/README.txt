KEEP CNAME in your repository. Upload or replace only these three HTML files in the same folder:
1. index.html = marijuana-leaf WTFdd.com homepage.
2. fn-team-original.html = Facebook f destination.
3. index25.html = High & Hungry rotating Best of Period orb destination, including the temporary Concepts popup.
Do not rename index.html or use a Best of Period page as the root homepage.
